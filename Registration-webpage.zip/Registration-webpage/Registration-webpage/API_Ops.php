<?php
function getActorDetails($actorId) {
	$curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => "https://online-movie-database.p.rapidapi.com/actors/get-bio?nconst=$actorId",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(
            "x-rapidapi-key: 838b7cd870mshee334278a835d7dp1144d7jsn020d21d0aa7b",
            "x-rapidapi-host: online-movie-database.p.rapidapi.com"
		),
	));

	$response = curl_exec($curl);
	$httpStatus = curl_getinfo($curl, CURLINFO_HTTP_CODE); // Get HTTP status code
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
		return array("error" => "cURL Error: $err");
	}

	if ($httpStatus !== 200) {
		return array("error" => "HTTP Error: $httpStatus");
	}

	return json_decode($response, true);
}

function getActorsBornToday($birthdate) {
	$date = new DateTime($birthdate);
	$day = $date->format('d');
	$month = $date->format('m');

	$curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => "https://online-movie-database.p.rapidapi.com/actors/list-born-today?month=$month&day=$day",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(

            "x-rapidapi-key: 838b7cd870mshee334278a835d7dp1144d7jsn020d21d0aa7b",
            "x-rapidapi-host: online-movie-database.p.rapidapi.com"

		),
	));

	$response = curl_exec($curl);
	$httpStatus = curl_getinfo($curl, CURLINFO_HTTP_CODE); // Get HTTP status code
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
		return array("error" => "cURL Error: $err");
	}

	if ($httpStatus !== 200) {
		return array("error" => "HTTP Error: $httpStatus");
	}

	return json_decode($response, true);
}

$birthdate = isset($_GET['birthdate']) ? $_GET['birthdate'] : "";

if ($birthdate) {
	$actors = getActorsBornToday($birthdate);

	if ($actors !== null) {
		echo "Response data from getActorsBornToday function: ";
		echo "<pre>";
		print_r($actors);
		echo "</pre>";
	} else {
		echo "No data retrieved from getActorsBornToday function.";
	}

	if (!empty($actors) && !isset($actors['error'])) {
		$actorNames = [];

		foreach ($actors as $actor) {
			$actorId = substr($actor, 6, 9);
			$actorDetails = getActorDetails($actorId);

			if (!empty($actorDetails) && !isset($actorDetails['error'])) {
				//echo json_encode(array("error" => "retrieved"));

				$actorNames[] = $actorDetails["name"];
			}
		}
		echo json_encode($actorNames);
	} else {
		echo json_encode(array("error" => "No actors found for today"));
	}
} else {
	echo json_encode(array("error" => "Birthdate not provided"));
}
	?>


