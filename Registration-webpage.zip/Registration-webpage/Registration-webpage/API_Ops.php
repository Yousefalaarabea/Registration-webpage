<?php
// Function to fetch actor details by ID
function getActorDetails($actorId) {
	$curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => "https://online-movie-database.p.rapidapi.com/actors/get-bio?nconst=$actorId",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(
            "x-rapidapi-key: 838b7cd870mshee334278a835d7dp1144d7jsn020d21d0aa7b",
            "x-rapidapi-host: online-movie-database.p.rapidapi.com"
		),
	));

	$response = curl_exec($curl);
	$httpStatus = curl_getinfo($curl, CURLINFO_HTTP_CODE); // Get HTTP status code
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
		return array("error" => "cURL Error: $err");
	}

	if ($httpStatus !== 200) {
		return array("error" => "HTTP Error: $httpStatus");
	}

	return json_decode($response, true);
}

// Function to fetch list of actors born today
function getActorsBornToday($birthdate) {
	$date = new DateTime($birthdate);
	$day = $date->format('d');
	$month = $date->format('m');

	$curl = curl_init();

	curl_setopt_array($curl, array(
		CURLOPT_URL => "https://online-movie-database.p.rapidapi.com/actors/list-born-today?month=$month&day=$day",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(

            "x-rapidapi-key: 838b7cd870mshee334278a835d7dp1144d7jsn020d21d0aa7b",
            "x-rapidapi-host: online-movie-database.p.rapidapi.com"

		),
	));

	$response = curl_exec($curl);
	$httpStatus = curl_getinfo($curl, CURLINFO_HTTP_CODE); // Get HTTP status code
	$err = curl_error($curl);

	curl_close($curl);

	if ($err) {
		return array("error" => "cURL Error: $err");
	}

	if ($httpStatus !== 200) {
		return array("error" => "HTTP Error: $httpStatus");
	}

	return json_decode($response, true);
}

// Retrieve the birthdate from the request
$birthdate = isset($_GET['birthdate']) ? $_GET['birthdate'] : "";

// Check if the birthdate is provided
if ($birthdate) {
	// Retrieve actors born today
	$actors = getActorsBornToday($birthdate);
	// Retrieve actors born today

	// Check if $actors is not null
	if ($actors !== null) {
		// Print out the response data
		echo "Response data from getActorsBornToday function: ";
		echo "<pre>";
		print_r($actors); // Print out the response data
		echo "</pre>";
	} else {
		// Handle the case when $actors is null (no data retrieved)
		echo "No data retrieved from getActorsBornToday function.";
	}

	// Check if actors are found
	if (!empty($actors) && !isset($actors['error'])) {
		// Array to store actor names
		$actorNames = [];

		// Iterate through each actor
		foreach ($actors as $actor) {
			// Extract actor ID
			$actorId = substr($actor, 6, 9);

			// Fetch actor details
			$actorDetails = getActorDetails($actorId);

			// Check if actor details are retrieved successfully
			if (!empty($actorDetails) && !isset($actorDetails['error'])) {
				//echo json_encode(array("error" => "retrieved"));
				// Extract actor name and add to the array
				$actorNames[] = $actorDetails["name"];
			}
		}

		// Encode actor names as JSON and return
		echo json_encode($actorNames);
	} else {
		// No actors found for today or error occurred
		echo json_encode(array("error" => "No actors found for today"));
	}
} else {
	// Birthdate not provided
	echo json_encode(array("error" => "Birthdate not provided"));
}
	?>


