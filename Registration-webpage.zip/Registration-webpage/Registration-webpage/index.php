<!--Registeration Webpage-->
<!--Yousef Alaa 20210476-->
<!--Bassem Wael 20210085-->
<!--Aliaa Adel  20210515-->
<!--Nahla Hesham  20210424-->
<!--Seif Eldien  20210536-->
<!--George Ayman  20210104-->

<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registration webpage</title>
<!--        <link rel="stylesheet" href="style/media.css">-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
              integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css">
    </head>
    <body class="main-col">
    <style>

        .Reg-form {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        body {
            background-image: url('D:/Yousef/Web/Registration-webpage/Registration-webpage/image.jpg');
            background-size: cover;
            background-position: center;
        }
        button {
            border: none;
            border-radius: 50px;
            padding: 15px 30px;
            background-color: #4CAF50;
            color: white;
            font-size: 16px;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
        }
        button:hover {
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }
    </style>
        <?php include "header.php"; ?>

    <div class="container">
        <div class="row d-flex justify-content-center mt-5">
            <div class="col-8">
                <div class="Reg-form main-col text-center p-5">

                    <button><a href="signup.php">Sign Up</a></button>
                </div>
            </div>
        </div>
    </div>

    <?php include "footer.php"; ?>
    </body>
    </html>


