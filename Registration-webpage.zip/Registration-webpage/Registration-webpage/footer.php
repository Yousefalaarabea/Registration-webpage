<footer>
  <div class="container">
    <p>&copy; registration form of Web based Project</p>
  </div>
</footer>

<head>
<style>

footer {
    background-color: #333;
    filter: brightness(80%);
    padding: 35px;
    text-align: center;
    position: absolute;
    bottom: 2;
    width: 100%;

    /*position: absolute;*/
    /*bottom: 0;*/
    /*width: 100%;*/
    /*background-color: #333; !* Example color *!*/
    /*color: #fff; !* Example text color *!*/
    /*padding: 10px 0;*/
    /*text-align: center;*/
}

footer p {
    font-size: 11px;
    color: #eee;
}

</style>
</head>