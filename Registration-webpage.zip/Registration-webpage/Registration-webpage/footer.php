<footer>
  <div class="container">
    <p>&copy; registration form of Web based Project</p>
  </div>
</footer>

<head>
<style>

footer {
    background-color: #333;
    filter: brightness(80%);
    padding: 35px;
    text-align: center;
    position: absolute;
    bottom: 2;
    width: 100%;
}

footer p {
    font-size: 11px;
    color: #eee;
}

</style>
</head>